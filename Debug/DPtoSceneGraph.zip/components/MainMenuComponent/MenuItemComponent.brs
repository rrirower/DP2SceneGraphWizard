' entry point of MenuItemComponent
sub Init()
    m.menuIcon = m.top.findNode("icon")
    m.menuTitle = m.top.findNode("titleLabel")
end sub

'''''''''
' itemContentChanged: Event hanlder - handles the change in each menu item.
' 
'''''''''
sub itemContentChanged()
    itemContent = m.top.itemContent
    if itemContent <> invalid
        m.menuTitle.text = itemContent.title
        m.menuIcon.uri = itemContent.hdposterUrl
    end if
end sub'//# sourceMappingURL=./MenuItemComponent.bs.map