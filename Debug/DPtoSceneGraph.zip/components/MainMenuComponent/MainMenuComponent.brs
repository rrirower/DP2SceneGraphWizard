' (c) Copyright 2024, Michael Harnad
'import "pkg:/components/UILogic/SearchScreenLogic.bs"
'import "pkg:/components/UILogic/TagScreenLogic.bs"
'import "pkg:/components/UILogic/WatchlistScreenLogic.bs"
'import "pkg:/components/UILogic/ScreenStackLogic.bs"

'''''''''
' Init: Initializes this component.
' 
'''''''''
sub Init()
    ' Read the main menu items.
    mainMenuItems = ParseJson(ReadAsciiFile("pkg:/source/main_menu.json"))
    ' Get reference to main menu list.
    m.mainMenuList = m.top.findNode("mainMenuList")
    m.mainMenuList.itemSelected = 0
    m.mainMenuList.observeField("itemSelected", "OnMenuItemSelected")
    ' Build the main menu.
    BuildMainMenu(mainMenuItems)
end sub

'''''''''
' BuildMainMenu: Builds the main menu component.
' 
'''''''''
function BuildMainMenu(_mainMenu as object) as void
    ' Initialize the menu action array.
    m.menuActionArray = []
    numEnabledMenuItems = 0
    ' Create the main menu root.
    mainMenuRoot = CreateObject("roSGNode", "ContentNode")
    ' Load the enabled menu items.
    for each menuItem in _mainMenu.MainMenuItems
        ' Ensure that the menu item is enabled.
        if menuItem["enabled"]
            numEnabledMenuItems++
            m.menuActionArray.Push(menuItem["action"])
            mainmenuItem = CreateObject("roSGNode", "ContentNode")
            mainmenuItem.title = menuItem["title"]
            mainmenuItem.HDPosterUrl = menuItem["bitmap"]
            mainMenuRoot.appendChild(mainmenuItem)
        end if
    end for
    ' Now, position the menu on the screen.
    ' Get the Roku device display size.
    rokuSize = GetRokuDisplaySize()
    halfScreenHeight = rokuSize["h"] / 2
    ' Set the location of the menu based on the Roku device resolution.
    menuHeight = (numEnabledMenuItems * m.mainMenuList.itemSize[0]) + ((numEnabledMenuItems - 1) * m.mainMenuList.itemSpacing[1])
    halfMenuHeight = menuHeight / 2
    topMenuList = (halfScreenHeight - halfMenuHeight)
    m.mainMenuList.translation = [
        m.mainMenuList.translation[0]
        topMenuList
    ]
    m.mainMenuList.numRows = numEnabledMenuItems
    ' Populate the menu items in the markuplist.
    m.mainMenuList.content = mainMenuRoot
    m.mainMenuList.drawFocusFeedback = false
end function

'''''''''
' OnMenuItemSelected: 
' 
' @param {object} _itemSelected
'''''''''
sub OnMenuItemSelected(_itemSelected as object) as void
    menuSelection = _itemSelected.GetData()
    menuAction = m.menuActionArray[menuSelection]
    m.mainMenuList.itemFocused = menuSelection
    ' If the menu list has the focus...
    if m.mainMenuList.hasFocus()
        ' User has selected the Home menu item.
        if menuAction = "MENU_HOME"
            CloseToHome()
            ' User has selected the Watchlist menu item.
        else if menuAction = "MENU_WATCHLIST"
            if not WatchlistIsEmpty()
                SlideScreenLeft()
                ShowWatchlistScreen()
            else
                AnnounceNoMenuItems("Your Watchlist is empty.")
            end if
            ' User has selected the Tags menu item.
        else if menuAction = "MENU_TAGS"
            SlideScreenLeft()
            ShowTagsScreen()
            ' User has selected the Search menu item.
        else if menuAction = "MENU_SEARCH"
            SlideScreenLeft()
            ShowSearchScreen()
            ' User has selected the Series menu item.
        else if menuAction = "MENU_SERIES"
            if m.global.SERIES_COUNT <> invalid and m.global.SERIES_COUNT > 0
                selectedTagContentArray = BuildArrayOfMediaTypes("series")
                SlideScreenLeft()
                ShowTagContentScreen(selectedTagContentArray)
            else
                AnnounceNoMenuItems()
            end if
            ' User has selected the Movies menu item.
        else if menuAction = "MENU_MOVIES"
            if m.global.MOVIES_COUNT <> invalid and m.global.MOVIES_COUNT > 0
                selectedTagContentArray = BuildArrayOfMediaTypes("movies")
                SlideScreenLeft()
                ShowTagContentScreen(selectedTagContentArray)
            else
                AnnounceNoMenuItems()
            end if
            ' User selected the TV specials menu item.
        else if menuAction = "MENU_TVSPECIALS"
            if m.global.TVSPECIAL_COUNT <> invalid and m.global.TVSPECIAL_COUNT > 0
                selectedTagContentArray = BuildArrayOfMediaTypes("tvspecials")
                SlideScreenLeft()
                ShowTagContentScreen(selectedTagContentArray)
            else
                AnnounceNoMenuItems()
            end if
        end if
    end if
end sub

'''''''''
' AnnounceNoMenuItems: Displays a message box to the user.
' 
' @param {string} I: the message to display. [_message="Content of this type is not available."]
'''''''''
function AnnounceNoMenuItems(_message = "Content of this type is not available." as string) as void
    message = []
    message.Push(_message)
    buttons = [
        "Ok "
    ]
    m.msgDialog = ShowAMessageDialog("Nothing to see here...", message, buttons)
    m.msgDialog.observeFieldScoped("buttonSelected", "onOk")
end function

'''''''''
' onOk: Handles click on the OK button.
' 
'''''''''
sub onOk()
    if m.msgDialog.buttonSelected = 0
        ' handle ok button here
        m.msgDialog.close = true
    end if
end sub

'''''''''
' onKeyEvent: Event handler - handles remote key presses.
' 
' @param {string} I: _key - key that was pressed.
' @param {boolean} I: _press - true if key was pressed, false if released.
' @return {boolean} - returns true if handled, else, false.
'''''''''
function onKeyEvent(_key as string, _press as boolean) as boolean
    handled = false
    ' If Right key press and the menu list has focus...
    if _key = "right" and _press = true and m.mainMenuList.hasFocus() = true
        SlideScreenLeft()
        handled = true
    end if
    return handled
end function

'''''''''
' SlideScreenLeft: Slide the screen to the Left by setting some attributes.
' 
'''''''''
function SlideScreenLeft() as void
    ' Get the parent screen.
    parentScreen = m.top.getParent().getParent()
    ' If the parentScreen is a layout for WatchList, get its parent.
    if parentScreen.id = "watchListLayout"
        parentScreen = parentScreen.getParent()
    end if
    ' Grid Screen.
    if parentScreen.subtype() = "GridScreen"
        ' Get the Grid rowlist.
        rowList = parentScreen.FindNode("rowList")
        rowList.SetFocus(true)
        ' Tags Screen.
    else if parentScreen.subtype() = "TagsScreen"
        ' Get the Grid tag array.
        gridArray = parentScreen.FindNode("tagPosterGrid")
        gridArray.SetFocus(true)
        ' Tag content screen.
    else if parentScreen.subtype() = "TagContentScreen"
        gridArray = parentScreen.FindNode("TagContentGrid")
        gridArray.SetFocus(true)
        ' Watchlist content screen.
    else if parentScreen.subtype() = "WatchlistScreen"
        gridArray = parentScreen.FindNode("watchlistPosterGrid")
        gridArray.SetFocus(true)
    end if
    ' Remove the focus bitmap.
    m.mainMenuList.drawFocusFeedback = false
    ' Resize the menu.
    m.mainMenuList.itemSize = [
        35
        35
    ]
end function'//# sourceMappingURL=./MainMenuComponent.bs.map