' (c) Copyright 2024, Michael Harnad








sub CheckSubscriptionAndStartPlayback(rowContent as Object, selectedItem = 0 as Integer, isSeries = false as Boolean)
    m.rowContent = rowContent
    m.selectedItem = selectedItem
    m.isSeries = isSeries
    ' Get channel subscription catalog.
    GetSubscriptionCatalog()
end sub

'''''''''
' GetSubscriptionCatalog: Gets the catalog of available subscriptions for this channel.
' 
'''''''''
function GetSubscriptionCatalog() as void
    ' retrieve purchases by calling channelStore command
    m.global.channelStore.command = "getCatalog"
    ' set an observer to be able to handle actions once loaded
    m.global.channelStore.ObserveField("catalog", "OnGetCatalogList")
end function

'''''''''
' OnGetCatalogList: Event handler - Rasied when the Channel store returns the product catalog.
' 
' @param {object} event
'''''''''
sub OnGetCatalogList(event as Object)
    m.global.channelStore.UnobserveField("catalog")
    catalog = event.GetData() ' extract loaded purchases
    ' Save channel subscription products.
    m.subscriptionProducts = catalog.getChildren(-1, 0)
    RunSubscriptionFlow()
end sub

'''''''''
' RunSubscriptionFlow: Starts the subscription wokrflow.
' 
'''''''''
sub RunSubscriptionFlow()
    ' Set a unique registry section name.
    m.subscriptionRegistryKey = m.global.channelTitle + "SubscriptionAccessToken"
    ' flag needed to show the trial for a new user
    m.isProductWithExpiredTrial = false
    ' show a progressive dialog while retrieving an user's purchases
    dialogCheckSubs = CreateObject("roSGNode", "ProgressDialog")
    dialogCheckSubs.title = "Checking subscription status..."
    ' to show a dialog set it to the interface field of MainScene
    m.top.dialog = dialogCheckSubs
    ' retrieve purchases by calling channelStore command
    m.global.channelStore.command = "getPurchases"
    ' set an observer to be able to handle actions once loaded
    m.global.channelStore.ObserveField("purchases", "OnGetPurchases")
end sub

'''''''''
' ValidateTransactionWithRokuPay: Starts a Roku Web API task to check for a valid transaction in the Channel Store.
' 
' @param {string} _action - I: The API action to perform.
' @param {string} _transactionId - I: the associated transaction Id to validate.
'''''''''
function ValidateTransactionWithRokuPay(_action as string, _transactionId as string) as void
    if _transactionId <> ""
        taskInput = {
            "transid": _transactionId
        }
    else
        ' Dummy transaction id since once was not found.
        taskInput = {
            "transid": "0"
        }
    endif
    CallRokuPayWebService(_action, taskInput, "isEntitled", "OnValidateTransactionWithRokuPay")
end function

'''''''''
' OnValidateTransactionWithRokuPay: Event handler - Raised when the ChannelStore has validated the transaction.
' 
'''''''''
sub OnValidateTransactionWithRokuPay()
    ' Stop the API task.
    m.webServiceApiTask.control = "stop"
    ' Both paths of the Roku workflow perforn the following regardless of 'isEntitled'.
    ' Get the publisher access token from the registry.
    accessTokenValue = CheckDeviceRegistryForValidAccessToken()
    if accessTokenValue <> ""
        ' Check the publisher Subscription server to see if the user is entitled to the video content.
        CheckEntitlementInSubscriptionServer(m.webServiceApiTask.transid)
    else
        GetTokenFromRokuCloud()
    end if
end sub

'''''''''
' CheckEntitlementInSubscriptionServer: Checks user entitlement to the content in the Subscription server.
' 
' @param {string} I: _transId - the transaction Id to check for entitlement.
'''''''''
function CheckEntitlementInSubscriptionServer(_transId as string) as void
    taskInput = {
        "transid": _transid
    }
    CallSubscriptionServer("check-entitlement", taskInput, "response", "OnCheckEntitlementInSubscriptionServer")
end function

'''''''''
' OnCheckEntitlementInSubscriptionServer: Event handler - Raised when the Subscription server checks content entitlement.
' 
'''''''''
function OnCheckEntitlementInSubscriptionServer() as void
    m.SubscriptionServiceApiTask.control = "stop"
    ' Parse the server response.
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    userIsEntitled = json["isEntitled"]
    ' If the Subscription server reports the user is entitled to the content,
    ' get a refresh token and store it on the device and in the Roku cloud.
    ' Then, grant access to the content.
    if userIsEntitled = "true"
        GetRefreshTokenStoreRegistryCloud()
    else
        ' Publisher's Subscription server reports user is not entitled to this content.
        ' Cancel user's subscription and entitlement.  Display channel UI.
        CancelSubscription(m.SubscriptionServiceApiTask.transid)
        ' Display the channel UI.
        DisplayChannelUI()
    end if
end function

'''''''''
' CancelSubscription: Cancels a user subscription in Roku pay.
' 
' @param {string} I: _transId - the transaction to cancel.
'''''''''
function CancelSubscription(_transId as string) as void
    taskInput = {
        "transid": _transId
    }
    CallRokuPayWebService("cancel-subscription", taskInput, "status", "OnCancelSubscription")
    ' Remove access token from device registry.
    UpdateDeviceRegistry(m.subscriptionRegistryKey, "", true)
    ' Remove Roku web token.
    m.global.channelStore.channelCredData = ""
    m.global.channelStore.command = "storeChannelCredData"
    ' Update user login status.
    UpdateLoginStatus("false")
end function

'''''''''
' OnCancelSubscription: Event handler - Raised when cancel-subscription ends.
' 
'''''''''
function OnCancelSubscription() as void
    ' Stop the API task.
    m.webServiceApiTask.control = "stop"
    json = ParseJson(m.webServiceApiTask.status)
    if json <> invalid
        print json["errorCode"]
        print json["errorDetails"]
        print json["errorMessage"]
        print json["status"]
    end if
end function

'''''''''
' DisplayChannelUI: Displays the Channel UI.
' 
'''''''''
function DisplayChannelUI() as void
    msg = []
    msg.Push("A valid login or subscription to this channel is required to view this content.")
    buttons = []
    buttons.Push("Sign in to my account using my email address")
    buttons.Push("Sign up and purchase a subscription")
    m.Dialog = ShowAMessageDialog("Please sign in or Sign up.", msg, buttons)
    m.Dialog.observeFieldScoped("buttonSelected", "OnSigninOrSignup")
    ' display the dialog
    scene = m.top.getScene()
    scene.dialog = m.Dialog
end function

'''''''''
' OnSigninOrSignup: Event handler - Raised when the user selects to sign in or sign up.
' 
'''''''''
function OnSigninOrSignup() as void
    ' Close the message dialog.
    m.dialog.close = true
    ' Did the user want to sign up for a subscription?
    if m.Dialog.buttonSelected = 1
        ' Display the Request For Info (RFI) screen.
        m.global.channelStore.ObserveField("userData", "OnUserSignupProvided")
        m.global.channelStore.requestedUserData = "email, firstname, lastname"
        m.global.channelStore.command = "getUserData"
    else
        ' User wants to sign into an existing account.
        m.global.channelStore.ObserveField("userData", "OnUserSigninProvided")
        m.global.channelStore.requestedUserData = "email"
        info = CreateObject("roSGNode", "ContentNode")
        info.addFields({
            context: "signin"
        })
        m.global.channelStore.requestedUserDataInfo = info
        m.global.channelStore.command = "getUserData"
    end if
end function

'''''''''
' OnUserSignupProvided: Event handler - Rasied when the user selects to sign up for a Subscription.
' 
'''''''''
function OnUserSignupProvided() as void
    m.global.UnobserveField("userData")
    buttons = [
        "Ok"
    ]
    message = [
        "Please validate your email address for access to this channel."
    ]
    ' Did the user click Continue or Cancel?
    if m.global.channelStore.userData <> invalid
        ' User clicked Continue.
        m.userAllowedAccessToRfi = true
        CreateKeyboardDialog("Email validation", m.global.channelStore.userData.email, message, buttons)
    else
        ' User clicked Cancel.       
        m.userAllowedAccessToRfi = false
        CreateKeyboardDialog("Email validation", "", message, buttons)
    end if
    m.keyboardDialog.observeFieldScoped("buttonSelected", "OnSignupButtonSelected")
    ' Display a Standard keyboard to validate the user credentials.
    m.top.dialog = m.keyboardDialog
end function

'''''''''
' OnSignupButtonSelected: Event handler - Raised when user clicks OK button on the signup keyboard.
' 
'''''''''
sub OnSignupButtonSelected()
    if m.keyboardDialog.buttonSelected = 0
        m.userEmail = m.keyboardDialog.text
        ' Check for a subscription for this email on the subscription server.
        SubscriptionServer_CheckForLinkedSubscription("check-linked-subscription", m.userEmail)
    end if
end sub

'''''''''
' OnUserSigninProvided: Event handler - Rasied when user clicks OK after accepting a signin email.
' 
' @return {dynamic} - returns invalid if user clicked Cancel.
'''''''''
function OnUserSigninProvided()
    m.global.UnobserveField("userData")
    ' userData invalid means the user selected 'Cancel' from the signin screen.
    if m.global.channelStore.userData = invalid
        return invalid
    else
        m.userEmail = m.global.channelStore.userData.email
        message = [
            "Please enter your account password."
        ]
        buttons = [
            "Ok"
        ]
        CreateKeyboardDialog("Account password", "", message, buttons)
        m.keyboardDialog.observeFieldScoped("buttonSelected", "OnSigninPasswordSelected")
        m.top.dialog = m.keyboardDialog
    end if
end function

'''''''''
' OnSigninPasswordSelected: Event handler - Raised when the user enters a password to signin.
' 
'''''''''
function OnSigninPasswordSelected() as void
    ' Close the keyboard dialog.
    m.top.dialog.close = true
    if m.keyboardDialog.buttonSelected = 0
        m.userPassword = m.keyboardDialog.text
        SubscriptionServer_ValidateUserCredentialsOnServer("validate-credentials", m.userEmail, m.userPassword)
    end if
end function

'''''''''
' ShowProductCatalog: Shows the channel product catalog to the user.
' 
' @return {dynamic}
'''''''''
function ShowProductCatalog()
    ' check if dialog hasn't been closed before by a user
    if m.top.dialog <> invalid
        m.top.dialog.close = true ' close previous dialog
    else
        return invalid
    end if
    dialog = CreateObject("roSGNode", "Dialog")
    ' Do we have any subscriptions to offer?
    if m.subscriptionProducts.Count() > 0
        ' create buttons on dialog with products info
        ' to create buttons we need to create an array of strings
        subscriptions = []
        m.activeCatalogItems = []
        for each product in m.subscriptionProducts
            if m.isProductWithExpiredTrial ' if trial has been already used
                ' then show only products without trial
                if product.freeTrialQuantity = 0
                    subscriptions.Push(product.name + " " + product.cost)
                    m.activeCatalogItems.Push({
                        code: product.code
                        name: product.name
                    })
                end if
            else ' if trial hasn't been already used
                ' then show only products with trial
                if product.freeTrialQuantity > 0
                    subscriptions.Push(product.name + " " + product.cost)
                    m.activeCatalogItems.Push({
                        code: product.code
                        name: product.name
                    })
                end if
            end if
        end for
        dialog.buttons = subscriptions ' set buttons to dialog field
        ' set an observer to handle actions on button press
        dialog.ObserveField("buttonSelected", "DoSubscriptionOrder")
    else
        ' no available subscription to get some
        dialog.title = "Error"
        dialog.message = "There are no available subscriptions at the moment."
    end if
    m.top.dialog = dialog ' Set dialog to MainScene
end function

'''''''''
' DoSubscriptionOrder: Event hanlder - Raised when the use selects a subscription.
' 
'''''''''
sub DoSubscriptionOrder() as void
    ' extract buttonSelected index from the dialog
    buttonSelectedIndex = m.top.dialog.buttonSelected
    ' extract catalog item as child by index from the channelStore node
    catalogItem = m.activeCatalogItems[buttonSelectedIndex]
    ' to create an order we need to create a ContentNode with children as products to purchase
    order = CreateObject("roSGNode", "ContentNode")
    product = order.CreateChild("ContentNode")
    ' also we need to set required info as code, name and quantity
    product.AddFields({
        code: catalogItem.code
        name: catalogItem.name
        qty: 1
    })
    ' do an order by setting order to channelStore field and calling its command
    m.global.channelStore.order = order
    m.global.channelStore.command = "doOrder"
    ' observe orderStatus to be able to handle order response
    m.global.channelStore.ObserveField("orderStatus", "OnSubscriptionOrderStatus")
end sub

'''''''''
' OnOrderStatus: Event handler - Raised when the subscription order is processed.
' 
' @param {object} event
'''''''''
sub OnSubscriptionOrderStatus(event as Object)
    orderStatus = event.GetData()
    if orderStatus <> invalid and orderStatus.status = 1
        ' If the order was successfuly processed, validate the transaction.
        transactionId = m.global.channelStore.orderStatus.getChild(0).purchaseId
        SubscriptionServer_ValidateNewOrder("validate-new-order", transactionId, m.global.channelStore.userData.email, m.global.channelStore.userData.firstname, m.global.channelStore.userData.lastname)
    else
        ' otherwise show error dialog
        dialog = CreateObject("roSGNode", "Dialog")
        dialog.title = "Error"
        dialog.message = "Failed to process your payment. Please try again."
        m.top.dialog = dialog
    end if
    m.global.channelStore.UnobserveField("orderStatus")
end sub

'''''''''
' CheckDeviceRegistryForValidAccessToken: Checks for a valid access token in the device registry.
' 
' @return {string} - returns the access token if found.  Else, returns "".
'''''''''
function CheckDeviceRegistryForValidAccessToken() as string
    ' Create an Access Token object.
    channelGuid = GetChannelGuid()
    accessTokenObject = AccessToken(channelGuid)
    ' Get a list of the subscription keys.
    accessTokenKeyList = accessTokenObject.GetKeyList()
    if accessTokenKeyList.Count() > 0
        ' Get the stored subscription access token.
        accessTokenValue = accessTokenObject.ReadBookmark(accessTokenKeyList[0])
    else
        accessTokenValue = ""
    end if
    return accessTokenValue
end function

'''''''''
' CheckValidAccessTokenInRokuCloud: Checks the Roku Cloud for the access token.
' 
'''''''''
function CheckValidAccessTokenInRokuCloud() as void
    m.global.channelStore.ObserveField("channelCred", "OnCheckValidAccessTokenInRokuCloud")
    m.global.channelStore.command = "getChannelCred"
end function

'''''''''
' OnCheckValidAccessTokenInRokuCloud: Event handler - Raised when the Channel data is returned.
' 
'''''''''
function OnCheckValidAccessTokenInRokuCloud() as void
    m.global.channelStore.UnobserveField("channelCred")
    if m.global.channelStore.channelCred <> invalid
        if m.global.channelStore.channelCred.json <> invalid
            json = ParseJson(m.global.channelStore.channelCred.json)
            if json <> invalid
                accessTokenStoredInCloud = json["channel_data"]
                ' If no access token can be found in the Roku cloud, display the channel UI.
                if accessTokenStoredInCloud = ""
                    DisplayChannelUI()
                else
                    ' Check for a signed in user.
                    if UserIsSignedIn() = true
                        ' Update the device registry with the cloud token.
                        UpdateDeviceRegistry(m.subscriptionRegistryKey, accessTokenStoredInCloud)
                        ' Update the user's login status.
                        UpdateLoginStatus()
                        ' Grant access to the content.
                        GrantAccessToContent()
                    else
                        ' User is not signed in.  Display channel UI.
                        DisplayChannelUI()
                    end if
                end if
            end if
        end if
    end if
end function

'''''''''
' FindSubscriptionTransactionId: Finds the transaction id associated with the channel subscription.
' 
' @param {object} I: _purchases - List of channel subscriptions.
' @return {string} - the transaction id associated with the channel subscription.
'''''''''
function FindSubscriptionTransactionId(_purchases as object) as string
    transid = ""
    ' Check each purchase made by the associated user account.
    for each purchase in _purchases
        ' Scan through our subscription catalog for a match on product code.  If found,
        ' return the transaction id.
        for each subscription in m.subscriptionProducts
            if purchase.code = subscription.code
                transid = purchase.purchaseId
                exit for
            end if
        end for
        ' If we found the transaction Id, get out...
        if transid <> ""
            exit for
        end if
    end for
    return transid
end function

'''''''''
' OnGetPurchases: Event handler - Raised when purchases are retrieved from the Channelstore.
' 
' @param {object} event
'''''''''
sub OnGetPurchases(event as Object)
    m.global.channelStore.UnobserveField("purchases")
    purchases = event.GetData() ' extract loaded purchases
    ' check if dialog hasn't been closed before by a user
    if m.top.dialog <> invalid
        m.top.dialog.close = true ' close previous dialog
    else
        return
    end if
    ' Get all subscription purchases.
    allPurchases = purchases.GetChildren(-1, 0)
    ' Find the transaction Id associated with an active subscription.
    transactionId = FindSubscriptionTransactionId(allPurchases)
    ' Check the Chanel store for entitlement to the video content.
    ValidateTransactionWithRokuPay("validate-transaction", transactionId)
end sub

'''''''''
' SubscriptionServer_CheckTokenInEntitlementServer: Calls the Subscription server to check the access token.
' 
' @param {string} I: _action - the API action verb.
' @param {string} I: _accessTokenName - the token name.
'''''''''
function SubscriptionServer_CheckTokenInEntitlementServer(_action as string, _accessTokenName as string) as void
    taskInput = {
        "accessToken": _accessTokenName
    }
    CallSubscriptionServer(_action, taskInput, "response", "OnCheckTokenInEntitlementServer")
end function

'''''''''
' OnCheckTokenInEntitlementServer: Event handler - Raised when the Subscription server checks for an entitlement token.
' 
'''''''''
function OnCheckTokenInEntitlementServer() as void
    m.SubscriptionServiceApiTask.control = "stop"
    ' Parse the server response.
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    refreshToken = json["accessToken"]
    ' Is the access token still valid?
    if refreshToken <> invalid and refreshToken <> ""
        UpdateDeviceRegistryAndRokuCloud(refreshToken)
    else
        ' The access token is INVALID.  Remove the access token on the device.
        UpdateDeviceRegistry(m.subscriptionRegistryKey, "", true)
    end if
end function

'''''''''
' SubscriptionServer_CheckForLinkedSubscription: Checks to see if the user email is already linked to a subscription on the server.
' 
' @param {string} I: _action - the API action verb.
' @param {string} _email
'''''''''
function SubscriptionServer_CheckForLinkedSubscription(_action as string, _email as string) as void
    taskInput = {
        "email": _email
    }
    CallSubscriptionServer(_action, taskInput, "response", "OnCheckForLinkedSubscription")
end function

'''''''''
' OnCheckForLinkedSubscription: Event handler - Rasied when the subscription server checks the user email.
' 
'''''''''
function OnCheckForLinkedSubscription() as void
    m.SubscriptionServiceApiTask.control = "stop"
    ' Parse the server response.
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    buttons = [
        "Ok"
    ]
    ' Is the user email linked to an active subscription?
    if json["subscriptionIsLinked"] = "true"
        ' Create a Standard Keyboard Dialog.
        message = [
            "An email address was found that is linked to an active subscription."
        ]
        CreateKeyboardDialog("An active subscription was found for this account", "Please re-enter your password", message, buttons)
        m.keyboardDialog.observeFieldScoped("buttonSelected", "OnPasswordOkButtonSelected")
        ' Display a Standard keyboard to validate the user credentials.
        m.top.dialog = m.keyboardDialog
    else
        ' No subscription linked to this account.
        message = [
            "Please enter a password to create your channel account and click 'OK' to start your subscription."
        ]
        CreateKeyboardDialog("Password validation", "", message, buttons)
        ' If the user allowed access to their email address, generate a password for them.
        if m.userAllowedAccessToRfi = true
            password = GenerateARandomPassword()
            m.keyboardDialog.text = password
        end if
        m.keyboardDialog.observeFieldScoped("buttonSelected", "OnNewPasswordOkButtonSelected")
        ' Display a Standard keyboard to validate the user credentials.
        m.top.dialog = m.keyboardDialog
    end if
end function

'''''''''
' OnPasswordOkButtonSelected: Event handler - Raised when the user clicks the Ok button after entering a password.
' 
'''''''''
sub OnPasswordOkButtonSelected()
    m.top.dialog.close = true ' close previous dialog
    m.userPassword = m.keyboardDialog.text
    SubscriptionServer_ValidateUserCredentialsOnServer("validate-credentials", m.userEmail, m.userPassword)
end sub

'''''''''
' OnNewPasswordOkButtonSelected: Event handler - Raised when the user purchases a new subscription.
' 
'''''''''
sub OnNewPasswordOkButtonSelected()
    m.top.dialog.close = true ' close previous dialog
    ' show a progressive dialog while retrieving a catalog
    dialogCheckProducts = CreateObject("roSGNode", "ProgressDialog")
    dialogCheckProducts.title = "Retrieving available products..."
    m.top.dialog = dialogCheckProducts ' set dialog to MainScene
    m.userPassword = m.keyboardDialog.text
    ShowProductCatalog()
end sub

'''''''''
' SubscriptionServer_ValidateUserCredentialsOnServer: Validates the user credentials on the subscription server.
' 
' @param {string} I: _action - the API action verb.
' @param {string} I: _email - user email address.
' @param {string} I: _password - user password.
'''''''''
function SubscriptionServer_ValidateUserCredentialsOnServer(_action as string, _email as string, _password as string) as void
    taskInput = {
        "email": _email
        "password": _password
    }
    CallSubscriptionServer(_action, taskInput, "response", "OnValidateUserCredentialsOnServer")
end function

'''''''''
' OnValidateUserCredentialsOnServer: Event handler - Raised when the Subscription server validates user credentials.
' 
'''''''''
function OnValidateUserCredentialsOnServer() as void
    m.SubscriptionServiceApiTask.control = "stop"
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    if json["credentialsValid"] = "true"
        ' Mark the user as logged in.
        UpdateLoginStatus()
        ' Get an access token from the publisher's Subscription server.
        SubscriptionServer_ObtainAccessToken("get-access-token")
    end if
end function

'''''''''
' SubscriptionServer_ObtainAccessToken: Obtains an Access token from the Subscription Server.
' 
' @param {string} I: _action - the API action verb.
'''''''''
function SubscriptionServer_ObtainAccessToken(_action as string) as void
    taskInput = {
        "notneeded": ""
    }
    CallSubscriptionServer(_action, taskInput, "response", "OnObtainAccessToken")
end function

'''''''''
' OnObtainAccessToken: Event handler - Raised when the Subscription server returns an access token.
' 
'''''''''
function OnObtainAccessToken() as void
    m.SubscriptionServiceApiTask.control = "stop"
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    ' Subscription token returned from the Server.
    subscriptionToken = json["accessToken"]
    UpdateDeviceRegistryAndRokuCloud(subscriptionToken)
    ' Grant access to the content.
    GrantAccessToContent()
end function

'''''''''
' SubscriptionServer_ValidateNewOrder: Validates a new subscription order on the Subscription server.
' 
' @param {string} I: _action - the API action verb.
' @param {string} I: _transactionId - the new order transaction ID.
' @param {string} I: _email - the user email.
' @param {string} I: _firstname - the user's first name.
' @param {string} I: _lastname - the uer's last name.
'''''''''
function SubscriptionServer_ValidateNewOrder(_action as string, _transactionId as string, _email as string, _firstname as string, _lastname as string) as void
    taskInput = {
        "transid": _transactionId
        "email": _email
        "firstname": _firstname
        "lastname": _lastname
    }
    CallSubscriptionServer(_action, taskInput, "response", "OnValidateNewOrder")
end function

'''''''''
' OnValidateNewOrder: Event handler - Raised when the Subscription server validates the new order.
' 
'''''''''
function OnValidateNewOrder() as void
    m.SubscriptionServiceApiTask.control = "stop"
    json = ParseJson(m.SubscriptionServiceApiTask.response.body)
    if json["orderIsOK"] = "true"
        UpdateDeviceRegistryAndRokuCloud(json["accessToken"])
        GrantAccessToContent()
    end if
end function

'''''''''
' UpdateDeviceRegistry: Updates the device registry.
' 
' @param {string} I: _key - the registry key.
' @param {string} I: _value - the key value.
' @param {boolean} I: [_deleteToken=false] - true to remove the access token, else, false.
'''''''''
function UpdateDeviceRegistry(_key as string, _value as string, _deleteToken = false as boolean) as void
    ' Get channel's unique identifier.
    channelGuid = GetChannelGuid()
    newAccessTokenObject = AccessToken(channelGuid)
    if _deleteToken <> true
        newAccessTokenObject.WriteBookmark(_key, _value)
    else
        newAccessTokenObject.DeleteBookmark(_key)
    end if
end function

'''''''''
' UpdateDeviceRegistryAndRokuCloud: Updates the Device registry and the Roku Cloud.
' 
' @param {string} I: _accessToken - the access token.
'''''''''
function UpdateDeviceRegistryAndRokuCloud(_accessToken as string) as void
    ' Store it in the device registry.
    UpdateDeviceRegistry(m.subscriptionRegistryKey, _accessToken)
    ' Store it in the Roku cloud.
    m.global.channelStore.ObserveField("storeChannelCredDataStatus", "OnChannelCredDataStatus")
    m.global.channelStore.channelCredData = _accessToken
    m.global.channelStore.command = "storeChannelCredData"
end function

'''''''''
' OnChannelCredDataStatus: Event handler - Raised when the Roku cloud has been updated.
' 
'''''''''
function OnChannelCredDataStatus() as void
    if m.global.channelStore.storeChannelCredDataStatus <> invalid
        ' DEBUG ONLY!
        'print "- response: " m.global.channelStore.storeChannelCredDataStatus.response
        'print "- status: " m.global.channelStore.storeChannelCredDataStatus.status
    end if
end function

'''''''''
' GetTokenFromRokuCloud: Asks the Roku cloud to return the access token.
' 
'''''''''
function GetTokenFromRokuCloud() as void
    ' Get access token from the Roku cloud.
    m.global.channelStore.ObserveField("channelCred", "OnTokenFromRokuCloud")
    m.global.channelStore.command = "getChannelCred"
end function

'''''''''
' OnTokenFromRokuCloud: Event handler - Raised when the Channel store returns the access token.
' 
'''''''''
function OnTokenFromRokuCloud() as void
    if m.global.channelStore.channelCred <> invalid
        if m.global.channelStore.channelCred.json <> invalid
            json = ParseJson(m.global.channelStore.channelCred.json)
            if json <> invalid
                accessTokenStoredInCloud = json["channel_data"]
                ' If valid access token was return from the Roku cloud, check for customer signed in.
                if accessTokenStoredInCloud <> ""
                    if UserIsSignedIn() = false
                        DisplayChannelUI()
                    else
                        ' Store access token from cloud in device registry.
                        UpdateDeviceRegistry(m.subscriptionRegistryKey, accessTokenStoredInCloud)
                        ' Update login status.
                        UpdateLoginStatus()
                        ' Grant access to the content.
                        GrantAccessToContent()
                    end if
                else
                    ' Valid access token not return from Roku cloud.  Display the channel UI.
                    DisplayChannelUI()
                end if
            end if
        end if
    end if
end function

'''''''''
' GetRefreshTokenStoreRegistryCloud: Gets a refresh token from the Subscription server
'                                   and stores it in the device registry and Roku cloud.
' 
'''''''''
function GetRefreshTokenStoreRegistryCloud() as void
    SubscriptionServer_ObtainAccessToken("get-access-token")
end function

'''''''''
' UserIsSignedIn: Checks to see if the user is currently signed into the channel.
' 
' @return {boolean} - returns true if signed in, else false.
'''''''''
function UserIsSignedIn() as boolean
    signedin = false
    channelGuid = GetChannelGuid()
    newLoginStatus = LoginStatus(channelGuid)
    userSignedIn = newLoginStatus.ReadBookmark("UserLoggedIn")
    if userSignedIn <> ""
        signedin = true
    end if
    return signedin
end function

'''''''''
' UpdateLoginStatus: Updates the user's login status.
' 
' @param {string} I: [_login="true"] - true to login, else, false to logoff.
'''''''''
function UpdateLoginStatus(_login = "true" as string) as void
    ' Update user login status.
    channelGuid = GetChannelGuid()
    newLoginStatus = LoginStatus(channelGuid)
    newLoginStatus.WriteBookmark("UserLoggedIn", _login)
end function

'''''''''
' CreateKeyboardDialog: Creates a keyboard dialog to collect info from the user.
' 
' @param {string} I: _title - title of the dialog.
' @param {string} I: _text - initial text, if any.
' @param {object} I: _message - message to display.
' @param {object} I: _buttons - buttons to display.
'''''''''
function CreateKeyboardDialog(_title as string, _text as string, _message as object, _buttons as object) as void
    ' Create a Standard Keyboard Dialog.
    m.keyboardDialog = createObject("roSGNode", "StandardKeyboardDialog")
    'keyboarddialog.backgroundUri = "pkg:/images/rsgde_dlg_bg_hd.9.png"
    m.keyboardDialog.buttons = _buttons
    m.keyboardDialog.text = _text
    m.keyboardDialog.title = _title
    m.keyboardDialog.message = _message
    m.keyboardDialog.palette = CreateADialogPalette()
end function

'''''''''
' CallSubscriptionServer: Calls the publisher Subscription server task to perform an action.
' 
' @param {string} I: _endpoint - the Rest API url endpoint.
' @param {object} I: _taskInput - input fields to call the endpoint.
' @param {string} I: _observeField - field to observe for event handler.
' @param {string} I: _observeEvent - the event handler when the task returns.
'''''''''
function CallSubscriptionServer(_endpoint as string, _taskInput as object, _observeField as string, _observeEvent as string) as void
    m.SubscriptionServiceApiTask = CreateObject("roSGNode", "SubscriptionServerApiTask") ' create task to access the Subscription server.
    m.SubscriptionServiceApiTask.endpoint = _endpoint
    ' Establish the task input parameters.
    for each input in _taskInput
        if input = "transid"
            m.SubscriptionServiceApiTask.transid = _taskInput[input]
        else if input = "accessToken"
            m.SubscriptionServiceApiTask.accessToken = _taskInput[input]
        else if input = "email"
            m.SubscriptionServiceApiTask.email = _taskInput[input]
        else if input = "password"
            m.SubscriptionServiceApiTask.password = _taskInput[input]
        end if
    end for
    m.SubscriptionServiceApiTask.ObserveField(_observeField, _observeEvent)
    m.SubscriptionServiceApiTask.control = "run" ' CallSubscriptionAPI in SubscriptionServerApiTask called here.
end function

'''''''''
' CallRokuPayWebService: Calls the Roku Pay Web Service API.
' 
' @param {string} I: _action - the action to perform.
' @param {object} I: _taskInput - input fields to call the endpoint.
' @param {string} I: _observeField - field to observe for event handler.
' @param {string} I: _observeEvent - the event handler when the task returns.
'''''''''
function CallRokuPayWebService(_action as string, _taskInput as object, _observeField as string, _observeEvent as string) as void
    m.webServiceApiTask = CreateObject("roSGNode", "WebServiceApiTask") ' create task for subscription status.
    m.webServiceApiTask.endpoint = _action
    ' Establish the task input parameters.
    for each input in _taskInput
        if input = "purchases"
            m.webServiceApiTask.purchases = _taskInput[input]
        else
            m.webServiceApiTask.transid = _taskInput[input]
        end if
    end for
    m.webServiceApiTask.ObserveField(_observeField, _observeEvent)
    m.webServiceApiTask.control = "run" ' CallApiFunction in WebServiceApiTask called here.
end function

'''''''''
' GrantAccessToContent: Grants access to the video content.
' 
'''''''''
function GrantAccessToContent() as void
    ShowVideoScreen(m.rowContent, m.selectedItem, m.isSeries)
end function
'//# sourceMappingURL=SubscriptionLogic.brs.map