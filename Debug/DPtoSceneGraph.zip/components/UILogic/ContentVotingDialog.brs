' (c) Copyright 2024, Michael Harnad
sub Init()
    m.dialogTitle = m.top.findNode("dialogTitle")
end sub

'''''''''
' SetDialogTitle: Sets the dialog title in the dialog.
' 
' @param {string} I: _title - content title.
'''''''''
function SetDialogTitle(_title as string) as void
    m.dialogTitle.primaryTitle = _title
end function
'//# sourceMappingURL=ContentVotingDialog.brs.map