' Watched class
' (c) Copyright 2024, Michael Harnad
' Registry section that tracks 'Watched' videos.

function __Watched_builder()
    instance = __Bookmark_builder()
    '''''''''
    ' new: Class constructor.
    '''''''''
    instance.super0_new = instance.new
    instance.new = sub()
        ' Call the base class constructor.
        m.super0_new("Watched")
    end sub
    '''''''''
    ' HasBeenWatched: Checks for previously 'watched' content.
    ' 
    ' @param {string} I: _contentId - the content ID.
    ' @return {boolean} - returns true if content was watched, else, false.
    '''''''''
    instance.HasBeenWatched = function(_contentId as string) as boolean
        return bslib_ternary(m.KeyExists(_contentId), true, false)
    end function
    return instance
end function
function Watched()
    instance = __Watched_builder()
    instance.new()
    return instance
end function'//# sourceMappingURL=./Watched.bs.map