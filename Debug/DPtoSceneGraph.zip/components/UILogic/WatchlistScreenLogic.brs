' (c) Copyright 2025, Michael Harnad
'import "pkg:/components/UILogic/ScreenStackLogic.bs"
'import "pkg:/source/utils.bs"

'''''''''
' ShowWatchlistScreen: Shows the Watchlist Screen.
' 
'''''''''
sub ShowWatchlistScreen()
    ' Create the Tags screen.
    m.WatchlistScreen = CreateObject("roSGNode", "WatchlistScreen")
    ' Show the Tags screen.
    ShowScreen(m.WatchlistScreen)
end sub
'//# sourceMappingURL=WatchlistScreenLogic.brs.map