' (c) Copyright 2024, Michael Harnad

'''''''''
' StartInputTask: Starts the input task.
' 
' @return {object} - returns the task object.
'''''''''
function StartInputTask() as object
    return CreateObject("roSGNode", "InputTask")
end function'//# sourceMappingURL=./InputLogic.bs.map