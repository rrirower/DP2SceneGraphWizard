' (c) Copyright 2024, Michael Harnad

'''''''''
' Cleanup: Run the Cleanup task.
' 
'''''''''
function Cleanup() as void
    ' Create a Cleanup task.
    m.cleanupTask = CreateObject("roSGNode", "CleanupTask")
    ' Start the cleanup task.
    m.cleanupTask.control = "run"
end function'//# sourceMappingURL=./CleanupLogic.bs.map