' AccessToken class
' (c) Copyright 2023, Michael Harnad
function __AccessToken_builder()
    instance = __Bookmark_builder()
    '''''''''
    ' new: Class constructor.
    ' 
    '''''''''
    instance.super0_new = instance.new
    instance.new = sub(_section as string)
        ' Call the base class constructor.
        m._accessToken = invalid
        m.super0_new(_section)
        ' Set some default values.
        m._accessToken = ""
    end sub
    ' Channel access token from Subscription server.
    return instance
end function
function AccessToken(_section as string)
    instance = __AccessToken_builder()
    instance.new(_section)
    return instance
end function
'//# sourceMappingURL=AccessTokenLogic.brs.map