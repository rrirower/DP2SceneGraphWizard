'import "pkg:/components/UILogic/ScreenStackLogic.bs"

'''''''''
' ShowSearchScreen: Shows the Search Screen.
' 
'''''''''
sub ShowSearchScreen()
    m.SearchScreen = CreateObject("roSGNode", "SearchScreen")
    gridScreen = invalid
    mainScene = m.top.getScene()
    ' Find the GridScreen.
    sceneChildren = mainScene.getChildren(- 1, 0)
    for each child in sceneChildren
        if child.subtype() = "GridScreen"
            gridScreen = child
        end if
    end for
    ' Clone the Grid screen content for the Search process.
    m.SearchScreen.content = gridScreen.content.clone(true)
    ' Show the Search screen.
    ShowScreen(m.SearchScreen)
end sub'//# sourceMappingURL=./SearchScreenLogic.bs.map