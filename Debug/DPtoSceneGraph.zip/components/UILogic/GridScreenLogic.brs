


sub ShowGridScreen()
    m.GridScreen = CreateObject("roSGNode", "GridScreen")
    m.GridScreen.ObserveField("rowItemSelected", "OnGridScreenItemSelected")
    ShowScreen(m.GridScreen) ' show GridScreen.    
end sub

sub OnGridScreenItemSelected(event as Object) ' invoked when GridScreen item is selected.
    m.grid = event.GetRoSGNode()
    ' extract the row and column of indices of the item the user selected.
    m.selectedIndex = event.GetData()
    ' the entire row from the RowList will be used by the Video node.
    rowContent = m.grid.content.GetChild(m.selectedIndex[0])
    m.contentObject = rowContent.getChildren(- 1, 0)
    ' If content was selected from the "Continue watching" row, show the user some options.
    if rowContent.TITLE = "Continue watching"
        message = [
            "Please select..."
        ]
        buttons = [
            "Resume playback"
            "Remove from Continue Watching"
            "Close"
        ]
        m.msgDialog = ShowAMessageDialog("Continue watching?", message, buttons)
        m.msgDialog.observeField("buttonSelected", "onContinueWatchingOption")
    else
        m.selectedRow = m.selectedIndex[0]
        ShowDetailsScreen(rowContent, m.selectedIndex[1])
    end if
end sub

'''''''''
' RegRemoveContinueWatchingContent: Remove the selected Continue Watching content from the registry.
' 
'''''''''
function RegRemoveContinueWatchingContent() as void
    cwBookmark = Bookmark()
    ' Get the selected content item.
    contentItem = m.contentObject[m.selectedIndex[1]]
    ' Delete its bookmark.
    cwBookmark.DeleteBookmark(contentItem.id)
    ' Delete it from the Continue Watching row.
    m.grid.content.getChild(0).RemoveChildIndex(m.selectedIndex[1])
    ' If there are no more items in Continue Watching, remove the row.
    if m.grid.content.getChild(0).getChildCount() = 0
        m.grid.content.RemoveChildIndex(0)
    end if
end function

'''''''''
' onContinueWatchingOption: Handles click on a button in the Continue Watching message dialog.
' 
'''''''''
sub onContinueWatchingOption()
    ' Resume Continue watching playback.
    if m.msgDialog.buttonSelected = 0
        ShowVideoScreen(m.contentObject[m.selectedIndex[1]], m.selectedIndex[1])
        ' Remove the selected content from Continue watching.
    else if m.msgDialog.buttonSelected = 1
        RegRemoveContinueWatchingContent()
    end if
    m.msgDialog.close = true
end sub'//# sourceMappingURL=./GridScreenLogic.bs.map