' (c) Copyright 2024, Michael Harnad
'import "pkg:/components/UILogic/BookmarkLogic.bs"
'import "pkg:/components/UILogic/VideoPlayer.bs"



sub Init()
    ' Save a reference to the Theme object.
    m.theme = Theme(m.top.SubType())
    ' Watch for changes in visibility.
    m.top.observeField("visible", "OnVisibleChanged")
    ' Get the reference to the main menu.
    m.mainMenu = m.top.FindNode("mainMenu")
    m.menuList = m.mainMenu.getChild(0)
    ' Get a reference to the options label.
    m.optionsLabel = m.top.FindNode("optionsLabel")
    m.theme.SetFont(m.optionsLabel)
    optionsText = m.theme.GetObjectText("optionsLabel", "optionsLabel")
    m.optionsLabel.text = m.theme.FormatText(m.optionsLabel, optionsText)
    ' Get a reference to the poster grid.
    m.watchlistGrid = m.top.FindNode("watchlistPosterGrid")
    if m.global.WATCHLIST = true
        m.watchlistGrid.useAtlas = "false"
        m.watchlistGrid.posterDisplayMode = m.global.THUMBNAIL_SCALING
    else
        m.watchlistGrid.useAtlas = "true"
    end if
    m.watchlistGrid.observeField("itemSelected", "OnWatchlistItemSelected")
    ' Build the watchlist grid.
    BuildWatchlistGrid()
end sub

'''''''''
' OnVisibleChanged: Event handler - handles changes in screen visibility.
' 
' @param {object} I: _visibility - true if visible, else, false.
'''''''''
sub OnVisibleChanged(_visibility as object)
    isVisible = _visibility.GetData()
    if isVisible
        m.watchlistGrid.SetFocus(true)
    end if
end sub

'''''''''
' BuildWatchlistGrid: Build the tag grid.
' 
'''''''''
function BuildWatchlistGrid() as void
    ' Get the Watchlist registry.
    m.watchlistReg = Bookmark("Watchlist")
    keyList = m.watchlistReg.GetKeyList()
    ' Iterate over the saved items in the Watchlist.
    if keyList <> invalid and keyList.Count() > 0
        ' Create a grid parent root item.
        gridRoot = CreateObject("roSGNode", "ContentNode")
        ' Get the content feed.
        contentFeed = ParseJson(ReadAsciiFile("tmp:/channelFeed.json"))
        ' Iterate over the list of keys in the Watchlist registry.
        for each key in keyList
            mediaType = m.watchlistReg.ReadBookmark(key)
            contentObject = ExtractRawContentFromFeed(mediaType, key, contentFeed)
            if contentObject <> invalid
                watchlistChild = CreateObject("roSGNode", "ContentNode")
                watchlistChild.shortdescriptionline1 = contentObject.shortDescription
                watchlistChild.HDPosterUrl = contentObject.thumbnail
                watchlistChild.SetFields({
                    "id": contentObject.id
                })
                watchlistChild.addFields({
                    "mediaType": mediaType
                })
                gridRoot.appendChild(watchlistChild)
            end if
        end for
        m.watchlistGrid.content = gridRoot
        m.menuList.drawFocusFeedback = false
        m.watchlistGrid.SetFocus(true)
    end if
end function

'''''''''
' OnWatchlistIemSelected: Event Handler - handles click on watchlist item.
' 
' @param {object} I: _watchlist - the index of the selected watchlist item.
'''''''''
sub OnWatchlistItemSelected(_watchlist as object)
    ' Get the index of the selected item.
    watchlistIndex = _watchlist.GetData()
    ' Get the associated watchlist item.
    watchlistContent = m.watchlistGrid.content.getChild(watchlistIndex)
    ' Define a AA array to create the ContentNode.
    args = {}
    args["dl_mediaType"] = watchlistContent.mediaType
    args["dl_id"] = watchlistContent.id
    ' Create a ContentNode for the selected content tag.
    content = CreateContentNodeFromRawObject(args)
    flag = bslib_ternary(args["dl_mediaType"] = "series", true, false)
    ShowVideoScreen(content, 0, flag)
end sub

'''''''''
' onKeyEvent: Event Handler - handles remote key presses.
' 
' @param {string} I: _key - key that was pressed.
' @param {boolean} I: _press - true if key was pressed, false if released.
' @return {boolean} - returns true if handled, else, false.
'''''''''
function onKeyEvent(_key as string, _press as boolean) as boolean
    handled = false
    ' If Left key press and the grid has focus...
    if _key = "left" and _press = true and m.watchlistGrid.hasFocus()
        m.menuList.itemSize = [
            150
            35
        ]
        m.menuList.jumpToItem = m.menuList.itemFocused
        m.menuList.drawFocusFeedback = true
        m.menuList.SetFocus(true)
        handled = true
    end if
    ' If Options key press (*)...
    if _key = "options"
        msg = [
            "Select an option."
        ]
        buttons = [
            "Remove the selected item"
            "Remove ALL items."
            "Cancel"
        ]
        m.msgDialog = ShowAMessageDialog("Manage your Watchlist.", msg, buttons)
        m.msgDialog.observeField("buttonSelected", "onOk")
    end if
    return handled
end function

'''''''''
' onOk: Handles click on Buttons in the message dialog.
' 
'''''''''
sub onOk()
    if m.msgDialog.buttonSelected = 0
        selectedItem = m.watchlistGrid.itemFocused
        itemToRemove = m.watchlistGrid.content.getChild(selectedItem)
        m.watchlistReg.DeleteBookmark(itemToRemove.id)
        m.watchlistGrid.content.removeChildIndex(selectedItem)
    else if m.msgDialog.buttonSelected = 1
        ' handle remove all items here.
        keyList = m.watchlistReg.GetKeyList()
        for each key in keylist
            m.watchlistReg.DeleteBookmark(key)
        end for
        m.watchlistGrid.content = invalid
    end if
    m.msgDialog.close = true
end sub
'//# sourceMappingURL=WatchlistScreen.brs.map