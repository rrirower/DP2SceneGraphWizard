' (c) Copyright 2024, Michael Harnad
'import "pkg:/components/UILogic/VideoPlayer.bs"

'''''''''
' GetRequestedContent: Gets the requested content from the Grid screen.
' 
' @param {object} I: _scene - the main scene object.
' @param {integer} I: _row - the row index in the grid.
' @param {integer} I: _column - the column index in the grid.
' @return {object} - returns the requested content object.
'''''''''
function GetRequestedContent(_scene as object, _row as integer, _column as integer) as object
    requestedContent = invalid
    if _scene <> invalid
        GridScreen = _scene.focusedChild
        if GridScreen <> invalid
            gridContent = GridScreen.content.getChildren(- 1, 0)
            rowContent = gridContent[_row].getChildren(- 1, 0)
            requestedContent = rowContent[_column]
        end if
    end if
    return requestedContent
end function

'''''''''
' FindVideoContent: Finds the video content within the current focused child.
' 
' @param {object} I: _focusedChild - the focused child.
' @return {object} - returns the found content.
'''''''''
function FindVideoContent(_focusedChild as object) as object
    foundContent = invalid
    if _focusedChild.SubType() = "GridScreen"
        rowList = _focusedChild.findNode("RowList")
        if rowList <> invalid
            focusedItem = rowList.rowItemFocused
            foundContent = GetRequestedContent(m.top, focusedItem[0], focusedItem[1])
        end if
    else if _focusedChild.SubType() = "EpisodesOnlyScreen" OR _focusedChild.SubType() = "EpisodesScreen"
        episodesList = _focusedChild.findNode("episodesList")
        foundContent = episodesList.content.getChild(episodesList.itemFocused)
    end if
    return foundContent
end function

'''''''''
' HandleRokuVoiceCommand: Handles Roku Voice commands.
' 
' @param {object} I: _eventData - the event data.
' @return {object} - returns the voice command status.
'''''''''
function HandleRokuVoiceCommand(_eventData as object) as object
    ' Get the voice command.
    voiceCommand = _eventData.command
    rc = {
        status: "unhandled"
    }
    ' Establish the Video renderer.
    if m.videoRenderer = invalid
        m.videoRenderer = m.videoPlayer
    end if
    ' PLAY.
    if m.videoRenderer = invalid AND voiceCommand = "play"
        ' Handle play command.        
        requestedContent = FindVideoContent(m.top.focusedChild)
        ShowVideoScreen(requestedContent, 0, false)
        rc.status = "success"
        ' PAUSE/STOP.
    else if voiceCommand = "pause" or voiceCommand = "stop"
        if m.videoRenderer.state = "playing"
            m.videoRenderer.control = "pause"
            rc.status = "success"
        else
            rc.status = "error.generic"
        end if
        'RESUME.
    else if (m.videoRenderer <> invalid and m.videoRenderer.state = "paused") and voiceCommand = "play"
        m.videoRenderer.control = "resume"
        rc.status = "success"
        ' START OVER.
    else if StringContains(voiceCommand, "start") AND StringContains(voiceCommand, "over")
        m.videoRenderer.seek = 0.0
        m.videoRenderer.control = "play"
        rc.status = "success"
        ' FAST FORWARD.
    else if StringContains(voiceCommand, "forward") = true
        length = m.videoRenderer.duration
        nFastForward = m.global.FAST_FORWARD.toInt()
        if m.videoRenderer.position + nFastForward < length
            seekPosition = m.videoRenderer.position + nFastForward
            m.videoRenderer.seek = seekPosition
            rc.status = "success"
        else
            rc.status = "error.generic"
        end if
        ' REWIND.
    else if StringContains(voiceCommand, "rewind") = true
        playbackPosition = m.videoRenderer.position
        nRewindBack = m.global.REWIND_BACK.toInt()
        if playbackPosition > nRewindBack
            seekPosition = playbackPosition - nRewindBack
            m.videoRenderer.seek = seekPosition
            rc.status = "success"
        else
            rc.status = "error.generic"
        end if
        ' WHAT'S PLAYING.
    else if voiceCommand = "nowplaying"
        if m.videoRenderer <> invalid
            WhatsPlaying(m.videoRenderer.content)
            rc.status = "success"
        else
            WhatsPlaying(invalid)
            rc.status = "error.generic"
        end if
    end if
    return rc
end function

'''''''''
' WhatsPlaying: During Roku Voice commands, displays What's playing.
' 
' @param {object} I: [_content=invalid] I: - the video content object.
'''''''''
function WhatsPlaying(_content = invalid as object) as void
    aaMetadata = invalid
    if _content <> invalid
        aaMetadata = {
            "title": _content.title
            "contentType": "movie "
        }
    end if
    appManager = CreateObject("roAppManager")
    appManager.SetNowPlayingContentMetaData(aaMetadata)
end function'//# sourceMappingURL=./Voice.bs.map