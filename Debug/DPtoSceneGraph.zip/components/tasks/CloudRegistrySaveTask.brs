' (c) Copyright 2025, Michael Harnad
'import "pkg:/components/ServerResources/ServerResources.bs"
'import "pkg:/source/utils.bs"

sub Init()
    ' Create url transfer object.
    m.xfer = CreateObject("roURLTransfer")
    m.xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    ' Save a reference to the Registry server class.
    m.serverAPIClass = ServerResources(2)
    ' Set the initial function to run.
    m.top.functionName = "SaveRegistryToCloud"
    ' Save the Device ID.
    m.top.channelID = GetChannelId()
end sub

'''''''''
' BuildRegistryPayload: Builds the Json payload for the Registry save.
' 
'''''''''
function BuildRegistryPayload() as void
    ' Save a reference to a Registry object.
    registryObject = CreateObject("roRegistry")
    ' Get a list of the current registry sections.
    sections = registryObject.GetSectionList()
    aaRegistry = {}
    if sections.Count() > 0
        for each section in sections
            iRegistrySection = CreateObject("roRegistrySection", section)
            keyList = iRegistrySection.GetKeyList()
            aaKeys = []
            for each key in keyList
                aaValues = {
                    "regKey": key
                    "regValue": iRegistrySection.Read(key)
                }
                aaKeys.Push(aaValues)
            end for
            aaRegistry[section] = aaKeys
        end for
    end if
    ' Format the current registry contents as a Json string.
    jsonRegistry = FormatJson(aaRegistry)
    ' Save the formatted string.
    m.top.registry = jsonRegistry
end function

'''''''''
' SaveRegistryToCloud: Saves the registry to the cloud.
' 
'''''''''
function SaveRegistryToCloud() as void
    ' Build a Json payload that contains the current registry.
    BuildRegistryPayload()
    try
        ' Call the user's server via REST.
        apiURL = m.serverAPIClass.GetServerURL("registry", "cloud-save-registry")
        apiURL = apiURL + "?channelId=" + m.top.channelID + "&userId=" + m.global.CHANNEL_USER_ID + "&reg=" + m.xfer.Escape(m.top.registry)
        m.xfer.RetainBodyOnError(true)
        m.xfer.SetURL(apiURL)
        ' Return a JSON response.
        m.xfer.AddHeader("accept", "application/json")
        ' DEBUG: Get the returned response.
        'rsp = m.xfer.GetToString()
        m.xfer.GetToString()
        ' DEBUG: Parse the returned response.
        'json = ParseJson(rsp)
    catch exception
        DebugPrint(exception.message, "Error")
    end try
end function'//# sourceMappingURL=./CloudRegistrySaveTask.bs.map