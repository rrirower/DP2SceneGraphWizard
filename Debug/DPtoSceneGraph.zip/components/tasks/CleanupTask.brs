' (c) Copyright 2024, Michael Harnad
'import "pkg:/components/UILogic/BookmarkLogic.bs"
'import "pkg:/source/utils.bs"

' Per Roku Certification 4.10, 30 days for minimum bookmarks.


sub Init()
    DebugPrint("Starting Cleanup tasks.")
    ' Set the function to run.
    m.top.functionName = "RunCleanup"
    ' Observe when the task is done.
    m.top.ObserveField("taskend", "OnCleanupComplete")
    ' Create a DateTime object.
    dateTimeObject = CreateObject("roDateTime")
    m.todayEpoch = dateTimeObject.AsSeconds()
end sub

'''''''''
' RunCleanup: Runs any cleanup processes.
' 
'''''''''
function RunCleanup() as void
    ' Remove expired video bookmarks.
    RemoveExpiredVideoBookmarks()
    ' Indicate the task has ended.
    m.top.taskend = true
end function

'''''''''
' RemoveExpiredVideoBookmarks: Removes any expired video bookmarks.
' 
'''''''''
function RemoveExpiredVideoBookmarks() as void
    DebugPrint("Cleanup task: RemoveExpiredVideoBookmarks")
    videoBookmarkClass = Bookmark()
    videoBookmarkList = videoBookmarkClass.GetKeyList()
    if videoBookmarkList.Count() > 0
        for each contentId in videoBookmarkList
            bookmarkCreationDate = videoBookmarkClass.GetBookmarkProperty(contentId, "creationDate").toInt()
            bookmarkDuration = m.todayEpoch - bookmarkCreationDate
            if bookmarkDuration >= (30 * 86400)
                DebugPrint("Removing expired bookmark " + contentId)
                videoBookmarkClass.DeleteBookmark(contentId)
            end if
        end for
    end if
end function

'''''''''
' OnCleanupComplete: Event handler - handles Cleanup task stop.
' 
'''''''''
function OnCleanupComplete() as void
    DebugPrint("Cleanup tasks ended.")
    ' Stop the task.
    m.top.control = "stop"
end function
'//# sourceMappingURL=CleanupTask.brs.map