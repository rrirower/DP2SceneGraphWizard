' (c) Copyright 2024, Michael Harnad
'import "pkg:/source/utils.bs"
'import "pkg:/source/Theme.bs"
'import "pkg:/components/SearchScreen/SearchResults.bs"

' Search types.


sub Init()
    ' The function to run when the task starts.
    m.top.functionName = "SearchForContent"
    ' Set the theme for the Search Screen.
    m.theme = Theme("SearchScreen")
end sub

'''''''''
' SearchForContent: Searches through the search indices for a match on search input.
' 
'''''''''
function SearchForContent() as void
    ' Get the parent Search screen.
    m.searchScreen = m.top.getParent()
    ' Get the search results label.
    m.searchResultsLabel = m.top.searchScreen.FindNode("searchResults")
    ' Set the font for the label.
    m.theme.SetFont(m.searchResultsLabel)
    ' Define the object to receive the Search results.
    m.SearchResultsObject = SearchResults(m.searchScreen)
    ' Define a String object for use later.
    m.stringObject = CreateObject("roString")
    ' Define an array that will define the search set.
    searchIndex = []
    ' Load prior search results to improve performance.     
    priorSearchResults = LoadSearchResults(m.top.textInput)
    ' If we have a prior search subset, use it.  Otherwise, use the global content index.
    if priorSearchResults <> invalid AND priorSearchResults.Count() > 0
        searchIndex = priorSearchResults
    else
        searchIndex = m.top.searchIndex
    end if
    ' Scan the Search index looking for a match.
    for each indexEntry in searchIndex
        foundContent = false
        ' Search within the Title field.
        rc = FindStringWithinIndex(indexEntry, m.top.textInput, 0)
        if rc = true then
            foundContent = true
        end if
        ' Search within the Long Description field.
        rc = FindStringWithinIndex(indexEntry, m.top.textInput, 1)
        if rc = true then
            foundContent = true
        end if
        ' Search within the Tags field.
        rc = FindStringWithinIndex(indexEntry, m.top.textInput, 2)
        if rc = true then
            foundContent = true
        end if
        ' If content was found, save it as Search content.
        if foundContent = true
            m.SearchResultsObject.UpdateSearchResults(indexEntry)
        end if
    end for
    ' Get the tally of each found content type.
    separateContentItems = {}
    separateContentItems = m.SearchResultsObject.GetIndividualContentArrays()
    for each item in separateContentItems.Items()
        if item.key = "movies"
            m.top.foundMovies = item.value
        else if item.key = "livefeeds"
            m.top.foundLiveFeeds = item.value
        else if item.key = "series"
            m.top.foundSeries = item.value
        else if item.key = "episodes"
            m.top.foundEpisodes = item.value
        else if item.key = "shortFormVideos"
            m.top.foundShortFormVideos = item.value
        else if item.key = "tvSpecials"
            m.top.foundTvSpecials = item.value
        end if
    end for
    ' Save these Search results to the TMP folder.
    m.SearchResultsObject.SaveSearchResultsToTmp(m.top.textInput)
    ' Set the Search task content.
    m.top.searchContent = m.SearchResultsObject.GetTheSearchContent()
end function

'''''''''
' FindStringWithinIndex: Finds a string within a search index entry.
' 
' @param {object} I: _indexEntry - the index entry.
' @param {string} I: _string - the string target.
' @param {searchType} I: _type - the search type (target).
' @return {boolean} - returns true if found, else, false.
'''''''''
function FindStringWithinIndex(_indexEntry as object, _string as string, _type as object) as boolean
    foundContent = false
    ' Search within Title.
    if _type = 0
        m.stringObject.SetString(LCase(_indexEntry.title))
        if m.stringObject.Instr(LCase(_string)) <> -1
            foundContent = true
        end if
        ' Search within Long Description.
    else if _type = 1
        m.stringObject.SetString(LCase(_indexEntry.longdescription))
        if m.stringObject.Instr(LCase(_string)) <> -1
            foundContent = true
        end if
        ' Search within Tags.
    else if _type = 2
        if _indexEntry.tags <> invalid and _indexEntry.tags.Count() > 0
            for each tag in _indexEntry.tags
                m.stringObject.SetString(LCase(tag))
                if m.stringObject.Instr(LCase(_string)) <> -1
                    foundContent = true
                    exit for
                end if
            end for
        end if
    end if
    return foundContent
end function

'''''''''
' SaveSearchResults: Saves the Search results to tmp so that they can be used
'                       in subsequent searches.
' 
' @param {object} I: _results - the current search results.
'''''''''
function SaveSearchResults(_results as object) as void
    aaSearchResults = {}
    aaSearchResults["input"] = m.top.textInput
    aaSearchResults["targets"] = _results
    ' Save the Search results to tmp memory.
    tempFile = "tmp:/SearchResults" + "_" + m.top.textInput + ".json"
    WriteAsciiFile(tempFile, FormatJson(aaSearchResults))
end function

'''''''''
' LoadSearchResults: Loads the prior Search results to improve Search performance.
' 
' @param {string} I: _input - the current input string.
' @return {object} - Returns the prior Search results.
'''''''''
function LoadSearchResults(_input as string) as object
    ' Get the length of the input string.
    inputLength = Len(_input)
    if inputLength = 1
        return invalid
    end if
    ' If a matching prior Search results file does not exist, return.
    if FileExists("tmp:/", "SearchResults_" + Left(_input, inputLength) + ".json") = false
        return invalid
    end if
    tempFile = "tmp:/SearchResults" + "_" + Left(_input, inputLength) + ".json"
    aaSearchResults = ParseJson(ReadAsciiFile(tempFile))
    if aaSearchResults <> invalid
        return aaSearchResults["targets"]
    else
        return invalid
    endif
end function
'//# sourceMappingURL=SearchTask.brs.map