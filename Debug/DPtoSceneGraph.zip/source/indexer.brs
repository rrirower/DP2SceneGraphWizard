' (c) Copyright 2026, Michael Harnad

'''''''''
' InitContentIndex: Initialize a content search index.
' 
'''''''''
function InitContentIndex() as void
    ' Define an assoc array.
    m.contentIndex = []
    ' Download the search index.
    m.index = DownloadAFile(m.global.INDEX_URL).json
end function

'''''''''
' SearchIndexIsAvailableFromServer: Checks for an available search index on a server.
' 
' @return {boolean} - returns true if index was downloaded, else, false.
'''''''''
function SearchIndexIsAvailableFromServer() as boolean
    return bslib_ternary(m.global.INDEX_URL <> invalid and m.global.INDEX_URL <> "", true, false)
end function

'''''''''
' IndexThisItem: Adds an item to the search index.
' 
' @param {object} I: _contentObject - the content object to index.
' @param {string} I: _mediaType - the content type.
'''''''''
function IndexThisItem(_contentObject as object, _mediaType as string) as void
    if _mediaType <> "series"
        description = (function(_contentObject)
                __bsConsequent = _contentObject.longDescription
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return _contentObject.shortDescription
                end if
            end function)(_contentObject)
        indexEntry = {
            id: _contentObject.id
            title: _contentObject.title
            longDescription: description
            mediaType: _mediaType
            tags: (function(__bsCondition, _contentObject)
                    if __bsCondition then
                        return _contentObject.tags
                    else
                        return invalid
                    end if
                end function)(_contentObject.tags <> invalid, _contentObject)
        }
        m.contentIndex.Push(indexEntry)
    else
        ' Save the Series object.
        description = (function(_contentObject)
                __bsConsequent = _contentObject.longDescription
                if __bsConsequent <> invalid then
                    return __bsConsequent
                else
                    return _contentObject.shortDescription
                end if
            end function)(_contentObject)
        indexEntry = {
            id: _contentObject.id
            title: _contentObject.title
            longDescription: description
            mediaType: _mediaType
            tags: (function(__bsCondition, _contentObject)
                    if __bsCondition then
                        return _contentObject.tags
                    else
                        return invalid
                    end if
                end function)(_contentObject.tags <> invalid, _contentObject)
        }
        m.contentIndex.Push(indexEntry)
        ' Save the Episodes within a Season.
        if _contentObject.seasons <> invalid
            for each season in _contentObject.seasons
                ' Initialize an Episode index.
                episodeIndex = 0
                for each episode in season.episodes
                    description = (function(episode)
                            __bsConsequent = episode.longDescription
                            if __bsConsequent <> invalid then
                                return __bsConsequent
                            else
                                return episode.shortDescription
                            end if
                        end function)(episode)
                    indexEntry = {
                        id: episode.id
                        series: _contentObject.id
                        title: episode.title
                        episodeIndex: episodeIndex
                        longDescription: description
                        mediaType: "episode"
                    }
                    m.contentIndex.Push(indexEntry)
                    episodeIndex++
                end for
            end for
        else
            ' Save the Episodes within a Series.
            ' Initialilze an Episode index.
            episodeIndex = 0
            for each episode in _contentObject.episodes
                description = (function(episode)
                        __bsConsequent = episode.longDescription
                        if __bsConsequent <> invalid then
                            return __bsConsequent
                        else
                            return episode.shortDescription
                        end if
                    end function)(episode)
                indexEntry = {
                    id: episode.id
                    series: _contentObject.id
                    title: episode.title
                    episodeIndex: episodeIndex
                    longDescription: description
                    mediaType: "episode"
                }
                m.contentIndex.Push(indexEntry)
                episodeIndex++
            end for
        endif
    end if
end function

'''''''''
' AddIndexToGlobalNode: Adds the search index to the Global node.
' 
'''''''''
function AddIndexToGlobalNode() as void
    ' Save the Search indices to the global node.
    m.global.addFields({
        "ContentIndex": m.contentIndex
    })
end function
'//# sourceMappingURL=indexer.brs.map