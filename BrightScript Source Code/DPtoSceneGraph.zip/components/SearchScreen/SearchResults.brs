' Search Results class
' (c) Copyright 2026, Michael Harnad
function __SearchResults_builder()
    instance = {}
    '''''''''
    ' new: Class constructor.
    ' 
    ' @param {object} I: _searchScr - the Search screen object.
    '''''''''
    instance.new = sub(_searchScr as object)
        m._searchScreen = invalid
        m._searchScreenList = invalid
        m._foundMovies = invalid
        m._foundLiveFeeds = invalid
        m._foundSeries = invalid
        m._foundEpisodes = invalid
        m._foundShortFormVideos = invalid
        m._foundTvSpecials = invalid
        m._searchResults = invalid
        m._searchContent = invalid
        m._foundMovies = []
        m._foundLiveFeeds = []
        m._foundSeries = []
        m._foundEpisodes = []
        m._foundShortFormVideos = []
        m._foundTvSpecials = []
        m._searchResults = []
        m._searchContent = []
        ' Save the Search screen object.
        m._searchScreen = _searchScr
        ' Get a reference to the Search results list.
        m._searchScreenList = m._searchScreen.FindNode("searchList")
        ' Create the parent node for the Search results.
        m._searchScreenList.content = CreateObject("roSGNode", "ContentNode")
    end sub
    ' The Search screen object.
    ' Reference to the Search screen list.
    ' Define some arrays to hold the totals of each type of content that was found during the search.
    ' Define a temporary array to hold intermediate results.
    ' Define an array to contain the results of the Search process.
    '''''''''
    ' SaveIndexItemToSearchResults: Saves an index item to the Search Results array.
    ' This array is saved to the tmp folder to improve Search processing.
    ' 
    ' @param {object} I: _indexItem - the index item.
    '''''''''
    instance.SaveIndexItemToSearchResults = function(_indexItem as object) as void
        m._searchResults.Push(_indexItem)
    end function
    '''''''''
    ' UpdateSearchResults: Updates the Search results with the found content item.
    ' 
    ' @param {object} I: _indexEntry - the index item that associates to the content item.
    '''''''''
    instance.UpdateSearchResults = function(_indexEntry as object) as void
        ' Add to the Search target for the next set of keystrokes.
        m.SaveIndexItemToSearchResults(_indexEntry)
        ' Extract the matching item (from the GridScreen) and add it to the search list array.
        searchListItem = m._searchScreen.callfunc("GetContentById", _indexEntry.id)
        ' If the item was not found, and, it's an Episode, we need to build a content node dynamically.
        if searchListItem = invalid and _indexEntry.mediatype = "episode"
            searchListItem = CreateContentNodeFromRawObject({
                "dl_mediaType": _indexEntry.mediatype
                "dl_id": _indexEntry.id
            })
        end if
        if searchListItem <> invalid
            m._searchContent.Push(searchListItem)
            if _indexEntry.mediatype = "movies"
                m._foundMovies.Push(searchListItem)
            else if _indexEntry.mediatype = "livefeeds"
                m._foundLiveFeeds.Push(searchListItem)
            else if _indexEntry.mediatype = "series"
                m._foundSeries.Push(searchListItem)
            else if _indexEntry.mediatype = "episode"
                searchListItem.AddFields({
                    "episodeindex": _indexEntry.episodeindex
                })
                m._foundEpisodes.Push(searchListItem)
            else if _indexEntry.mediatype = "shortFormVideos"
                m._foundShortFormVideos.Push(searchListItem)
            else if _indexEntry.mediatype = "tvSpecials"
                m._foundTvSpecials.Push(searchListItem)
            end if
            ' Add this content item to the Search screen list.
            m._searchScreenList.content.appendChild(searchListItem)
        end if
    end function
    '''''''''
    ' GetIndividualContentArrays: Gets the individual Search content results.
    ' 
    ' @return {object} - returns an assoc array that contains individual results.
    '''''''''
    instance.GetIndividualContentArrays = function() as object
        individualContentArrays = {}
        individualContentArrays.AddReplace("movies", m._foundMovies)
        individualContentArrays.AddReplace("livefeeds", m._foundliveFeeds)
        individualContentArrays.AddReplace("series", m._foundSeries)
        individualContentArrays.AddReplace("episodes", m._foundEpisodes)
        individualContentArrays.AddReplace("shortFormVideos", m._foundShortFormVideos)
        individualContentArrays.AddReplace("tvSpecials", m._foundTvSpecials)
        return individualContentArrays
    end function
    '''''''''
    ' SaveSearchResultsToTmp: Save the Search results to the TMP folder.
    ' 
    ' @param {string} I: _inputKeyStroke - the keystroke that started the Search process.
    '''''''''
    instance.SaveSearchResultsToTmp = function(_inputKeyStroke as string) as void
        aaSearchResults = {}
        aaSearchResults["input"] = _inputKeyStroke
        aaSearchResults["targets"] = m._searchResults
        ' Save the Search results to tmp folder.
        tempFile = "tmp:/SearchResults" + "_" + _inputKeyStroke + ".json"
        WriteAsciiFile(tempFile, FormatJson(aaSearchResults))
    end function
    '''''''''
    ' GetTheSearchContent: Gets the Search content.
    ' 
    ' @return {object} - returns the Search content.
    '''''''''
    instance.GetTheSearchContent = function() as object
        return m._searchContent
    end function
    return instance
end function
function SearchResults(_searchScr as object)
    instance = __SearchResults_builder()
    instance.new(_searchScr)
    return instance
end function
'//# sourceMappingURL=./SearchResults.brs.map