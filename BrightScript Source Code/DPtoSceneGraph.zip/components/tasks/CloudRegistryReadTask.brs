' (c) Copyright 2025, Michael Harnad
'import "pkg:/components/ServerResources/ServerResources.bs"
'import "pkg:/source/utils.bs"




sub Init()
    ' Create url transfer object.
    m.xfer = CreateObject("roURLTransfer")
    m.xfer.SetCertificatesFile("common:/certs/ca-bundle.crt")
    ' Save a reference to the Registry server class.
    m.serverAPIClass = ServerResources(2)
    ' Set the initial function to run.
    m.top.functionName = "RetrieveRegistryFromCloud"
    ' Save the Device ID.
    m.top.channelID = GetChannelId()
end sub

'''''''''
' RetrieveRegistryFromCloud: Retrieves the cloud registry.
' 
'''''''''
function RetrieveRegistryFromCloud() as void
    ' Call the user's server via REST.
    apiURL = m.serverAPIClass.GetServerURL("registry", "cloud-get-registry")
    apiURL = apiURL + "?channelId=" + m.top.channelID + "&userId=" + m.top.userID
    m.xfer.SetURL(apiURL)
    ' Return a JSON response.
    m.xfer.AddHeader("accept", "application/json")
    rsp = m.xfer.GetToString()
    if rsp <> invalid and rsp <> ""
        ' Parse the returned response.
        json = ParseJson(rsp)
    else
        json = invalid
        DebugPrint("Back end server returned a null registry from the cloud.  This may be benign.", "Warning")
    end if
    if json <> invalid
        try
            ' Set the flag to indicate the registry status from the server.
            m.top.cloudRegReceived = true
            ' Save the returned registry json.
            m.top.regFromCloud = json
            ' Reload the registry.
            ReloadTheRegistry()
            ' Set the reg received flag.
            m.top.cloudRegReceived = true
        catch excp
            DebugPrint("Could not reload the registry from the cloud: " + excp.message, "Error")
            ' Set the flag to indicate the registry status from the server.
            m.top.cloudRegReceived = false
        end try
    else
        m.top.cloudRegReceived = false
    end if
end function

'''''''''
' ReloadTheRegistry: Reload the Registry from the Cloud.
' 
'''''''''
function ReloadTheRegistry() as void
    ' If the registry was successfully retrieved from the cloud, reload it here.
    if m.top.cloudRegReceived
        ' Reload the registry from the cloud.  Iterate through the registry sections
        ' returned from the cloud.
        for each registrySection in m.top.regFromCloud.Items()
            ' Get a bookmark reference to the Registry section on the local device.
            localBookmark = Bookmark(registrySection.key)
            ' Ensure the registry section from the cloud has values.
            if registrySection.value.Count() <> 0
                ' Iterate through the returned cloud registry sections.
                for each cloudRegItem in registrySection.value
                    ' Write Video Bookmarks to the local registry.
                    if registrySection.key = "VideoBookmarks"
                        ' Init a registry entry.
                        aaRegistryEntry = {}
                        aaRegistryEntry = ParseJson(cloudRegItem.regValue)
                        if aaRegistryEntry <> invalid
                            localBookmark.WriteBookmarkEntry(cloudRegItem.regKey, aaRegistryEntry, false)
                        endif
                        ' Write Watchlist and Credential Bookmarks to the local registry.
                    else if registrySection.key = "Watchlist" or registrySection.key = "Credentials"
                        if cloudRegItem.regValue <> invalid and cloudRegItem.regValue <> "null"
                            localBookmark.WriteBookmark(cloudRegItem.regKey, cloudRegItem.regValue, false)
                        end if
                    end if
                end for
            else
                ' Remove the registry section.
                localBookmark.DeleteRegistrySection(registrySection.key)
            end if
        end for
    end if
end function
'//# sourceMappingURL=./CloudRegistryReadTask.brs.map