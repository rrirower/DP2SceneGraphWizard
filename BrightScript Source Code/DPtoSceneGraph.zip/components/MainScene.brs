'import "pkg:/components/UILogic/ScreenStackLogic.bs"
'import "pkg:/components/UILogic/CleanupLogic.bs"
'import "pkg:/components/UILogic/InputLogic.bs"
'import "pkg:/components/UILogic/CloudRegistryTaskLogic.bs"
'import "pkg:/components/RokuVoice/Voice.bs"
'import "pkg:/source/Theme.bs"


' entry point of MainScene
sub Init()
    ' Save a reference to the Theme object.
    m.theme = Theme(m.top.SubType())
    ' Get the custom attributes and assign them to the global node.
    GetCustomAttributes()
    ' Watch for the main scene loaded flag.
    m.top.observeField("mainSceneLoaded", "OnSceneLoaded")
    ' Get a reference to the 'Next Episode' thumbnail.
    m.nextEpisodeThumbnail = m.top.findNode("nextEpisodeThumbnail")
    m.nextEpisodeThumbnail.loadDisplayMode = m.global.THUMBNAIL_SCALING
    ' Get a reference to the 'Return image'.
    m.returnImage = m.top.findNode("returnImage")
    m.returnImage.loadDisplayMode = m.global.THUMBNAIL_SCALING
    ' Get a reference to the nested 'Video' player.
    m.videoPlayer = m.top.findNode("Video")
    ' Set background color for scene.  Applied only if backgroundUri has empty value.
    m.top.backgroundColor = m.global.BACKGROUND_COLOR
    backgroundImage = m.global.BACKGROUND_IMAGE
    ' If background image is supplied, use it.
    if backgroundImage <> ""
        m.background = m.top.findNode("background")
        m.background.uri = backgroundImage
    else
        m.top.backgroundUri = ""
    end if
    ' Set a default user id globally.
    m.global.AddFields({
        "CHANNEL_USER_ID": ""
    })
    ' Create a ChannelStore object and attach it to the global node.
    m.global.AddField("channelStore", "node", false)
    m.global.channelStore = CreateObject("roSGNode", "ChannelStore")
    ' Query for a Backend server that persists video content over multiple devices.
    m.bReloadRegistryFromServer = QueryForEndpoint("registry", "cloud-get-registry")
    bServerFound = bslib_ternary(m.bReloadRegistryFromServer = true, true, false)
    m.global.addFields({
        "BE_REG_SERVER": bServerFound
    })
    ' If persistent video content is required, we need to reload the registry from
    ' the users server.  Check the user credentials to see if we already have a valid user id.
    if m.bReloadRegistryFromServer
        ' Get the channel user ID.
        m.top.userCredential = GetUserCredentials()
        ' If the channel user Id is not valid, ask Roku for a valid ID.
        validUserId = IsAValidUserId(m.top.userCredential)
        if not validUserId
            ' Get the Roku pucid and use it as the user id.
            GetRokuPucid()
        end if
    end if
    ' Display Loading indicator.
    m.loadingIndicator = m.top.FindNode("loadingIndicator")
    m.theme.SetFont(m.loadingIndicator)
    loadingText = m.theme.GetObjectText("loadingIndicator", "loadingIndicator")
    m.loadingIndicator.text = m.theme.FormatText(m.loadingIndicator, loadingText)
    ' Create an Input task.
    m.inputTask = StartInputTask()
    ' Define an event handler for the Input task.
    m.inputTask.Observefield("inputData", "HandleInputEvent")
    ' Start the input task.
    m.inputTask.control = "run"
    ' Initialize the screen stack.
    InitScreenStack()
    ' Show the grid screen.
    ShowGridScreen()
    ' Display 'busy' animation.
    m.spinner = m.top.findNode("busySpinner")
    m.spinner.poster.observeField("loadStatus", "OnShowSpinner")
    m.spinner.poster.uri = "pkg:/images/busyspinner_hd.png"
    ' DEBUG ONLY - Remove Roku cloud token.
    'm.global.channelStore.channelCredData = ""
    'm.global.channelStore.command = "storeChannelCredData"
    ' If we are NOT supporting persistent video content, or, we have a valid id,
    ' set the main scene loaded flag.
    if not m.bReloadRegistryFromServer or validUserId = true
        m.top.mainSceneLoaded = true
    end if
end sub

'''''''''
' OnSceneLoaded: Event handler - Handles processing the main scene loaded flag.
' 
'''''''''
sub OnSceneLoaded()
    ' Perform cleanup tasks.
    Cleanup()
    ' Load the channel contents.
    LoadChannelContent()
end sub

'''''''''
' GetRokuPucid: Gets the Roku 'pucid' that represents the user.
' 
'''''''''
function GetRokuPucid() as void
    ' Start the channel store task to obtain the channel cred info.
    m.global.channelStore.ObserveField("channelCred", "OnReceivedChannelCred")
    m.global.channelStore.command = "getChannelCred"
end function

'''''''''
' OnReceivedChannelCred: Event handler - handles processing the channel cred that is returned.
' 
'''''''''
function OnReceivedChannelCred() as void
    m.global.channelStore.UnobserveField("channelCred")
    ' Create a string object to hold the current user id.
    thisUserId = CreateObject("roString")
    ' Check for a valid returned object.
    if m.global.channelStore.channelCred <> invalid
        ' Do we have valid json?
        if m.global.channelStore.channelCred.json <> invalid
            ' Parse the json returned from the channel store.
            json = ParseJson(m.global.channelStore.channelCred.json)
            if json <> invalid and json["roku_pucid"] <> invalid
                ' Save the Roku pucid.
                m.global.CHANNEL_USER_ID = json["roku_pucid"]
                thisUserId.SetString(m.global.CHANNEL_USER_ID)
                ' If the credential retrieved from the registry is "fallback", modify it so
                ' that the back end server can recognize it has been updated.
                if IsAFallbackUserId(m.top.userCredential)
                    thisUserId.SetString(m.top.userCredential)
                    thisUserId.AppendString("=", 1)
                    thisUserId.AppendString(m.global.CHANNEL_USER_ID, Len(m.global.CHANNEL_USER_ID))
                end if
            else
                ' This is a temp fallback if the Channel Store fails to produce a valid pucid.
                ' Create a String object.
                stringObj = CreateObject("roString")
                stringObj.SetString("fallback-")
                channelGuid = GetChannelGuid()
                stringObj.AppendString(channelGuid, Len(channelGuid))
                ' Save the temporary user credential.
                m.global.CHANNEL_USER_ID = stringObj.toStr()
                thisUserId.SetString(m.global.CHANNEL_USER_ID)
            end if
            ' Write the user credentials to the local registry.
            SetUserCredentials(m.global.CHANNEL_USER_ID)
            ' Rebuild the registry from the specified server.
            RebuildRegistryFromServer(thisUserId)
            m.top.mainSceneLoaded = true
        end if
    end if
end function

'''''''''
' RebuildRegistryFromServer: Rebuilds the device registry from the specified server.
' 
' @param {string} I: _userId - the id of the user.
'''''''''
function RebuildRegistryFromServer(_userId as string) as void
    ' Create a Cloud Registry Task to read the registry from the cloud server.
    m.cloudRegistryReadTask = StartCloudRegistryTask()
    m.cloudRegistryReadTask.userID = _userId
    m.cloudRegistryReadTask.ObserveField("cloudRegReceived", "OnCloudRegReceived")
    m.cloudRegistryReadTask.control = "run"
    ' Save a reference to the registry save timer.
    m.registrySaveTimer = m.top.FindNode("registrySaveTimer")
    ' Set some timer attributes.
    m.registrySaveTimer.repeat = true
    m.registrySaveTimer.duration = m.global.REGISTRY_TIMER
    ' Watch for the timer to fire.
    m.registrySaveTimer.ObserveField("fire", "OnSaveRegistryTimerFired")
end function

'''''''''
' OnShowSpinner: Event handler - process spinner load status.
' 
'''''''''
sub OnShowSpinner()
    if m.spinner.poster.loadStatus = "ready"
        centerx = (1280 - m.spinner.poster.bitmapWidth) / 2
        centery = (720 - m.spinner.poster.bitmapHeight) / 2
        m.spinner.translation = [
            centerx
            centery
        ]
        m.spinner.visible = "true"
    end if
end sub

'''''''''
' OnCloudRegReceived: Event handler - handles the end of the Cloud registry task to
'                   retrieve the contents of the channel registry from a server.
' 
'''''''''
sub OnCloudRegReceived()
    ' Start the registry save timer.
    m.registrySaveTimer.control = "start"
end sub

'''''''''
' OnSaveRegistryTimerFired: Event handler - handles the registry save timer fire event.
' 
'''''''''
sub OnSaveRegistryTimerFired()
    'DebugPrint("Registry save timer fired.")
    ' If we're playing video content, save the current position.
    if m.videoPlayer.state = "playing"
        ' Define a bookmark object.
        playbackBookmark = Bookmark()
        ' Set the playback bookmark for the currently playing bookmark.
        playbackBookmark.UpdatePlaybackBookmark(m.videoPlayer)
    end if
end sub

'   The OnKeyEvent() function receives remote control key events.
function OnKeyEvent(key as String, press as Boolean) as Boolean
    result = false
    if press
        ' handle "back" key press.
        if key = "back"
            numberOfScreens = m.ScreenStack.appscreenStack.Count()
            ' close top screen if there are two or more screens in the screen stack.
            if numberOfScreens > 1
                CloseScreen(invalid)
                result = true
            end if
        end if
    end if
    ' The OnKeyEvent() function must return true if the component handled the event,
    ' or false if it did not handle the event.
    return result
end function

'''''''''
' GetScreenStack: Gets the screen stack componenet in those situations where the 'm' context is incorrect.
' 
' @param {dynamic} I: _parm - needed by callfunc().
' @return {object} - returns the screen stack component.
'''''''''
function GetScreenStack(_parm as dynamic) as object
    return m.screenStack
end function

'''''''''
' HandleInputEvent: Handles input events and passes them on to the appropriate handler.
' 
' @param {object} I: _event - the input event object.
'''''''''
function HandleInputEvent(_event as object) as void
    if type(_event) = "roSGNodeEvent" and _event.getField() = "inputData"
        inputData = _event.getData()
        if inputData <> invalid
            if inputData.type = "deeplink"
                SaveDeepLinkingArgs(m.top, inputData)
            else
                ret = HandleRokuVoiceCommand(inputData)
                m.InputTask.transportResponse = {
                    id: inputData.id
                    status: ret
                }
            end if
        end if
    end if
end function
'//# sourceMappingURL=./MainScene.brs.map