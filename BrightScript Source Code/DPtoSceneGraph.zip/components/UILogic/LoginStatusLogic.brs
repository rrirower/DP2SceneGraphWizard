' LoginStatus class
' (c) Copyright 2023, Michael Harnad
function __LoginStatus_builder()
    instance = __Bookmark_builder()
    '''''''''
    ' new: Class constructor.
    ' 
    '''''''''
    instance.super0_new = instance.new
    instance.new = sub(_section as string)
        ' Call the base class constructor.
        m._loggedIn = invalid
        m.super0_new(_section)
        ' Set some default values.
        m._loggedIn = "false"
    end sub
    ' User login status.
    return instance
end function
function LoginStatus(_section as string)
    instance = __LoginStatus_builder()
    instance.new(_section)
    return instance
end function
'//# sourceMappingURL=./LoginStatusLogic.brs.map