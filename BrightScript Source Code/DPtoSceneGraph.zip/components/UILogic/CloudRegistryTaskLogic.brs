' (c) Copyright 2025, Michael Harnad

'''''''''
' StartCloudRegistryReadTask: Starts the Cloud Registry Read task.
' 
' @return {object} - returns a pointer to the Task object.
'''''''''
function StartCloudRegistryTask() as object
    return CreateObject("roSGNode", "CloudRegistryReadTask")
end function

'''''''''
' StartCloudRegistrySaveTask: Starts the Cloud Registry Save task.
' 
' @return {object}
'''''''''
function StartCloudRegistrySaveTask() as object
    return CreateObject("roSGNode", "CloudRegistrySaveTask")
end function
'//# sourceMappingURL=./CloudRegistryTaskLogic.brs.map