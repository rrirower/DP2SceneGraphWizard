' Theme class
' (c) Copyright 2024, Michael Harnad
function __Theme_builder()
    instance = {}
    '''''''''
    ' new: Class constructor.
    ' 
    ' @param {string} I: screenName - name of the screen.
    '''''''''
    instance.new = sub(screenName as string)
        m._screenName = invalid
        m._themeJson = invalid
        m._screen = invalid
        m._screenName = screenName
        m._themeJson = ParseJson(ReadAsciiFile("pkg:/source/theme.json"))
        for each screen in m._themeJson.screens
            if screen.name = m._screenName
                m._screen = screen
                exit for
            end if
        end for
    end sub
    '''''''''
    ' GetFonts: Retrieves an array of font(s) from the theme file.
    ' 
    ' @param {string} I: _screenField - the name of the screen field to apply the font.
    ' @return {object} - returns array of the associated font(s) if found, else, null.
    '''''''''
    instance.GetFonts = function(_screenField as string) as object
        fonts = []
        for each scrField in m._screen.scrFields
            if scrField.fieldName = _screenField
                for each font in scrField.fonts
                    fonts.Push(font)
                end for
                return fonts
            end if
        end for
        return ""
    end function
    '''''''''
    ' SetFont: Sets the font of the passed object.
    ' 
    ' @param {object} I: _screenField - the _screenField MUST support drawingStyles.
    ' @param {string} I: _fontNames - array of font names to use.
    '''''''''
    instance.SetFont = function(_screenField as object) as void
        objectStyle = {}
        fonts = m.GetFonts(_screenField.id)
        ' Make sure the object and the font name are valid.
        if _screenField <> invalid
            for each font in fonts
                fontStyle = {}
                fontStyle.AddReplace(font.fontName, {
                    "fontSize": font.fontSize
                    "fontUri": font.FontUri
                    "color": font.color
                })
                objectStyle.Append(fontStyle)
            end for
            _screenField.drawingStyles = objectStyle
        end if
    end function
    '''''''''
    ' ConstructBracket: Constructs the Font brackets for the text.
    ' 
    ' @param {string} I: _fontName - the font name.
    ' @param {boolean} I: [_close=false] - true for closing bracket, else, false.
    ' @return {string} - returns the font bracket.
    '''''''''
    instance.ConstructBracket = function(_fontName as string, _close = false as boolean) as string
        result = ""
        if _close = false
            result = "<" + _fontName + ">"
        else
            result = "</" + _fontName + ">"
        end if
        return result
    end function
    '''''''''
    ' FormatText: Formats the past screenField's text using its associated font.
    ' 
    ' @param {object} I: _screenField - the screen field.
    ' @param {string} I: _text - the text to format.
    ' @param {integer} I: [_fontIndex=0] - the font index to use if not the default.
    ' @return {string} - returns the formatted text.
    '''''''''
    instance.FormatText = function(_screenField as object, _text as string, _fontIndex = 0 as integer) as string
        stringObj = CreateObject("roString")
        if _screenField <> invalid
            ' Get the fonts for this screen field.
            fonts = m.GetFonts(_screenField.id)
            fontToUse = fonts.GetEntry(_fontIndex)
            ' Format the field text.
            br = m.ConstructBracket(fontToUse.fontName)
            stringObj.AppendString(br, Len(br))
            stringObj.AppendString(_text, Len(_text))
            br = m.ConstructBracket(fontToUse.fontName, true)
            stringObj.AppendString(br, Len(br))
        end if
        return stringObj
    end function
    '''''''''
    ' SetButtonFont: Sets the button font for a ButtonGroup.
    ' 
    ' @param {object} I: _screenField - the refrenece to the ButtonGroup.
    ' @param {object} O: _textColors - associative array that receives the defined colors.
    ' @param {integer} I: [_fontIndex=0] - the font index to use if not the default.
    ' @return {object} - returns the Font object.
    '''''''''
    instance.SetButtonFont = function(_screenField as object, _textColors as object, _fontIndex = 0 as integer) as object
        buttonFont = invalid
        if _screenField <> invalid
            buttonFont = CreateObject("roSGNode", "Font")
            fonts = m.GetFonts(_screenField.id)
            fontToUse = fonts.GetEntry(_fontIndex)
            buttonFont.uri = fontToUse.fontUri
            buttonFont.size = fontToUse.fontSize
            _textColors["textColor"] = fontToUse.color
            _textColors["focusedTextColor"] = fontToUse.focusedTextColor
        end if
        return buttonFont
    end function
    '''''''''
    ' GetObjectText: Gets the text of a screen object.
    ' 
    ' @param {string} I: _screenField - the screen field name.
    ' @param {string} I: _objectName - the object within the _screenField.
    ' @return {string} - returns the object text.
    '''''''''
    instance.GetObjectText = function(_screenField as string, _objectName as string) as string
        if _screenField <> invalid
            for each scrField in m._screen.scrFields
                if scrField.fieldName = _screenField
                    if scrField.strings <> invalid
                        for each str in scrField.strings
                            if str.fieldName = _objectName
                                return str.text
                            end if
                        end for
                    end if
                end if
            end for
        end if
        return "Not Found"
    end function
    '''''''''
    ' GetObjectImage: Gets the image of a screen object.
    ' 
    ' @param {object} I: _screenField - the screen field.
    ' @param {string} I: _objectName - the object within the _screenField.
    ' @return {string} - returns the image file path.
    '''''''''
    instance.GetObjectImage = function(_screenField as object, _objectName as string) as string
        if _screenField <> invalid
            for each scrField in m._screen.scrFields
                if scrField.fieldName = _screenField
                    for each image in scrField.images
                        if image.fieldName = _objectName
                            return image.image
                        end if
                    end for
                end if
            end for
        end if
        return ""
    end function
    '''''''''
    ' GetObjectColor: Gets the color of a screen object.
    ' 
    ' @param {object} I: _screenField - the screen field.
    ' @param {integer} I: [_fontIndex=0] - the font index to use if not the default.
    ' @return {string} - returns the color code if ok, else, black (#000000)
    '''''''''
    instance.GetObjectColor = function(_screenField as object, _fontIndex = 0 as integer) as string
        color = "#000000"
        if _screenField <> invalid
            ' Get the fonts for this screen field.
            fonts = m.GetFonts(_screenField.id)
            fontToUse = fonts.GetEntry(_fontIndex)
            color = fontToUse.color
        end if
        return color
    end function
    '''''''''
    ' GetScreenObjectFromScreenName: Gets the screen object from the screen name.
    ' 
    ' @return {object} - returns the current screen object.
    '''''''''
    instance.GetScreenObjectFromScreenName = function() as object
        for each screen in m._themeJson.screens
            if screen.name = m._screenName
                return screen
            end if
        end for
        return invalid
    end function
    '''''''''
    ' GetButtonTextFromButtonName: Gets the button text from a button name.
    ' 
    ' @param {string} I: _buttonFieldName - the name of the button group field.
    ' @param {string} I: _buttonName - the individual button to retrieve.
    ' @return {string}
    '''''''''
    instance.GetButtonTextFromButtonName = function(_buttonFieldName as string, _buttonName as string) as string
        scrObject = m.GetScreenObjectFromScreenName()
        for each scrField in scrObject.scrFields
            if scrField.fieldName = _buttonFieldName
                for each str in scrField.strings
                    if str.fieldName = _buttonName
                        return str.text
                    end if
                end for
            end if
        end for
        return invalid
    end function
    return instance
end function
function Theme(screenName as string)
    instance = __Theme_builder()
    instance.new(screenName)
    return instance
end function
'//# sourceMappingURL=./Theme.brs.map